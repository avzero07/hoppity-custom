Scatter Softmax
===============

.. automodule:: torch_scatter.composite
   :noindex:

.. autofunction:: scatter_softmax

.. autofunction:: scatter_log_softmax
