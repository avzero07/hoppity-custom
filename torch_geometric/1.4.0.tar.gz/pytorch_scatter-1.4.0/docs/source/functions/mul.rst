Scatter Mul
===========

.. automodule:: torch_scatter
   :noindex:

.. autofunction:: scatter_mul
