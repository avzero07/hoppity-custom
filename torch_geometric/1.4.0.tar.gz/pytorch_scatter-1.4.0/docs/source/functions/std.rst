Scatter Std
===========

.. automodule:: torch_scatter
   :noindex:

.. autofunction:: scatter_std
