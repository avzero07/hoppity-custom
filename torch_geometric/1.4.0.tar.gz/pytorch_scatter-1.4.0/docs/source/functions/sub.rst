Scatter Sub
===========

.. automodule:: torch_scatter
   :noindex:

.. autofunction:: scatter_sub
