Scatter Max
===========

.. automodule:: torch_scatter
   :noindex:

.. autofunction:: scatter_max
