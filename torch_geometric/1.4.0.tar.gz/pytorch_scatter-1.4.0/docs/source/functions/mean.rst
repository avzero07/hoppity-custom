Scatter Mean
============

.. automodule:: torch_scatter
   :noindex:

.. autofunction:: scatter_mean
