Scatter LogSumExp
=================

.. automodule:: torch_scatter
   :noindex:

.. autofunction:: scatter_logsumexp
